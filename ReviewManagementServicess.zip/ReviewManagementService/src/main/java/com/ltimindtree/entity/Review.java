package com.ltimindtree.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="reviews")
public class Review {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String reviews;
	private double ratings;
	
	public Review() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Review(int id, String reviews, double ratings) {
		super();
		this.id = id;
		this.reviews = reviews;
		this.ratings = ratings;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getReviews() {
		return reviews;
	}

	public void setReviews(String reviews) {
		this.reviews = reviews;
	}

	public double getRatings() {
		return ratings;
	}

	public void setRatings(double ratings) {
		this.ratings = ratings;
	}

	@Override
	public String toString() {
		return "Review [id=" + id + ", reviews=" + reviews + ", ratings=" + ratings + "]";
	}
	
	

}
