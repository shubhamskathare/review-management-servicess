package com.ltimindtree.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.ltimindtree.dto.OrderEvent;
import com.ltimindtree.entity.Review;
import com.ltimindtree.exception.ReviewNotFoundException;
import com.ltimindtree.repository.ReviewRepository;
import com.ltimindtree.service.ReviewService;

@Service
public class ReviewServiceImpl implements ReviewService{
	
	@Autowired
	private ReviewRepository reviewRepo;

	@Override
	public Review createReview(Review review) {
		// TODO Auto-generated method stub
		return reviewRepo.save(review);
	}

	@Override
	public Review getReviewById(int id) throws ReviewNotFoundException {
		// TODO Auto-generated method stub
		return reviewRepo.findById(id).orElseThrow(()->new ReviewNotFoundException("Review", "Id", id));
	}

	@Override
	public Review updateReview(Review review, int id) throws ReviewNotFoundException {
		Review existingReview=  reviewRepo.findById(id).orElseThrow(()->new ReviewNotFoundException("Review", "Id", id));
		existingReview.setReviews(review.getReviews());
		existingReview.setRatings(review.getRatings());
		reviewRepo.save(existingReview);
		return existingReview;
	}
	
	private static final Logger logger=LoggerFactory.getLogger(ReviewServiceImpl.class);
	
	@KafkaListener(topics = "${spring.kafka.topic.name}", groupId = "${sping.kafka.consumer.group-id}")
	public void consume(OrderEvent event) {
		
	}

}
